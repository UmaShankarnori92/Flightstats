<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_LOG IN</name>
   <tag></tag>
   <elementGuidId>0ff7195d-3cb2-4a7d-b54f-7a0dd6c75af0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='content']/div/div/main/div/div/div/div[2]/div/form/div[2]/button/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.innerPadding > button[type=&quot;button&quot;] > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;LOG IN&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>b874fa8f-c9a4-4fe2-a757-990c1c1e1133</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>LOG IN</value>
      <webElementGuid>5efe3cf3-2ba4-4763-9f6d-3436dbc1e87d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;content&quot;)/div[1]/div[@class=&quot;content-holder&quot;]/main[@class=&quot;container&quot;]/div[@class=&quot;LoginContainer&quot;]/div[@class=&quot;sharedAccountFormContainer&quot;]/div[@class=&quot;sc-jWBwVP bpetZw&quot;]/div[2]/div[@class=&quot;innerContent&quot;]/form[1]/div[@class=&quot;innerPadding&quot;]/button[1]/div[1]</value>
      <webElementGuid>01c5b7f4-daeb-4594-875a-81d27d48a289</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='content']/div/div/main/div/div/div/div[2]/div/form/div[2]/button/div</value>
      <webElementGuid>6f81c8d0-2b7d-431f-a7bd-2a0251879cbc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Forgot Password?'])[1]/following::div[2]</value>
      <webElementGuid>f2fdf7dd-8f13-4d07-8af4-aaa91325b13e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Remember Me'])[1]/following::div[2]</value>
      <webElementGuid>df2b202a-9f91-442d-bd45-7da4e2a42253</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Create a New Account'])[1]/preceding::div[2]</value>
      <webElementGuid>895bf8b7-0af8-4f41-b721-aec9b28ca166</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form/div[2]/button/div</value>
      <webElementGuid>eff1234e-09d3-446c-94d8-1e511feb1f11</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'LOG IN' or . = 'LOG IN')]</value>
      <webElementGuid>1cba6ac6-7b15-4be4-8746-7b5e1c3ff88f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
